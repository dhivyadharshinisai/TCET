// Functional Interface
interface Sayable {
    String say(String name);
}
public class FunctionalInterfaces{
        public static void main(String[] args) {
        // Lambda expression 
        Sayable sayable = (name) -> "Hello, " + name + "! Welcome!";
        // Using the say method
        String greeting = sayable.say("DhivyaDharshini");
        System.out.println(greeting);
    }
}
