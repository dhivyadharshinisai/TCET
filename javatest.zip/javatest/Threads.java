// Implementing the Runnable interface
class NumberPrinter implements Runnable {
    public void run() {
        for (int i = 1; i <= 5; i++) {
            System.out.println(i);
        }
    }
}
public class Threads {
    public static void main(String[] args) {
        // Creating a new thread 
        Thread thread = new Thread(new NumberPrinter());
        // Starting the thread
        thread.start();
    }
}
