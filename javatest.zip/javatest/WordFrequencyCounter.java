import java.util.HashMap;
import java.util.Scanner;
public class WordFrequencyCounter {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String text = scanner.nextLine();
        String normalizedText=text.toLowerCase();
        String[] words = normalizedText.split("\\s+");
        // Creating a HashMap
        HashMap<String, Integer> wordCountMap = new HashMap<>();
        // Counting the frequency of each word
        for (String word : words) {
            wordCountMap.put(word, wordCountMap.getOrDefault(word, 0) + 1);
        }
        System.out.println("Frequencies of each word:");
        for (String word : wordCountMap.keySet()) {
            System.out.println(word + ": " + wordCountMap.get(word));
        }
        scanner.close();
    }
}
